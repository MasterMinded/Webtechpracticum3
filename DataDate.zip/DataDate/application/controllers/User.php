<?php
class User extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	}

	public function login()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = "Login";
		$data['naam'] = $this->session->gebruiker['nickname'];
		$data['ingelogd'] = $this->session->ingelogd;

		$this->form_validation->set_rules('gebruikersnaam', 'Gebruikersnaam', 'required');
    	$this->form_validation->set_rules('wachtwoord', 'Wachtwoord', 'required');

		if($this->form_validation->run() === FALSE)
		{
			$this->load->view('templates/header', $data);
			$this->load->view('user/login', $data);
			$this->load->view('templates/footer');
		}
		else
		{
			$userinfo = $this->user_model->login();
			if ($userinfo !== FALSE)
			{
				$this->session->gebruiker = $userinfo;
				$this->session->ingelogd = TRUE;

				$data['naam'] = $this->session->gebruiker['nickname'];
				$data['ingelogd'] = $this->session->ingelogd;

				$this->load->view('templates/header', $data);
				$this->load->view('user/loginsucces');
				$this->load->view('templates/footer');
			}
			else
			{
				$this->load->view('templates/header', $data);
				$this->load->view('user/onjuist');
				$this->load->view('user/login', $data);
				$this->load->view('templates/footer');
			}
			
		}
	}

	public function registreren()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = "Registreren";
		$data['naam'] = $this->session->gebruiker['nickname'];
		$data['ingelogd'] = $this->session->ingelogd;
		
		$this->form_validation->set_rules('gebruikersnaam', 'Gebruikersnaam', 'required');
    	$this->form_validation->set_rules('mail', 'Emailadres', 'required|valid_email');
    	$this->form_validation->set_rules('wachtwoord1', 'Wachtwoord', 'required');
		$this->form_validation->set_rules('wachtwoord2', 'Wachtwoordcheck', 'required|matches[wachtwoord1]');
		$this->form_validation->set_rules('voornaam', 'Voornaam', 'required');
    	$this->form_validation->set_rules('achternaam', 'Achternaam', 'required');
		$this->form_validation->set_rules('dob', 'Geboortedatum', 'required');
    	$this->form_validation->set_rules('geslacht', 'Geslacht', 'required');
		$this->form_validation->set_rules('voorkeur', 'Geslachtsvoorkeur', 'required');
    	$this->form_validation->set_rules('agemin', 'Leeftijdsvoorkeur minimum', 'required');
		$this->form_validation->set_rules('agemax', 'Leeftijdsvoorkeur maximum', 'required');
    	//$this->form_validation->set_rules('foto', 'Foto', 'required');
		$this->form_validation->set_rules('aboutyou', 'Iets over jezelf', 'required');
				
		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('templates/header', $data);
			$this->load->view('user/registreren', $data);
			$this->load->view('templates/footer');
		}
		else
		{
			$userinfo = $this->user_model->checkifnew();
			if ($userinfo == TRUE)
			{
				$user = $this->input->post('gebruikersnaam');
				$voornaam = $this->input->post('voornaam');
				$achternaam = $this->input->post('achternaam');
				$email = $this->input->post('mail');
				$geslacht = $this->input->post('geslacht');
				$gebdat = $this->input->post('dob');
				$foto = $this->input->post('foto');
				$beschrijving = $this->input->post('aboutyou');
				$voorkeur = $this->input->post('voorkeur');
				$agemin = $this->input->post('agemin');
				$agemax = $this->input->post('agemax');
				$wachtwoord = password_hash($this->input->post('wachtwoord1'), PASSWORD_DEFAULT);
				
				
				//$upload = array('upload_data' => $this->upload->data());
				//$this->upload->do_upload('profilepic');
				//$data_upload_files = $this->upload->data();
				//$foto = $data_upload_files[full_path];
				
				$data = array(
					'nickname' => $user,
					'voornaam' => $voornaam,
					'achternaam' => $achternaam,
					'emailadres' => $email,
					'geslacht' => $geslacht,
					'geboortedatum' => $gebdat,
					//'foto' => $foto,
					'beschrijving' => $beschrijving,
					'geslachtsvoorkeur' => $voorkeur,
					'leeftijdsvoorkeurmin' => $agemin,
					'leeftijdsvoorkeurmax' => $agemax,
					'wachtwoordhash' => $wachtwoord,
					'admin' => 0
					);
				$this->db->insert("Accounts", $data);

				$this->load->view('templates/header', $data);
				$this->load->view('user/upload_form', $data);
				$this->load->view('templates/footer');
			}
			else
			{
				$this->load->view('templates/header', $data);
				$this->load->view('user/registerfail');
				$this->load->view('user/registreren', $data);
				$this->load->view('templates/footer');
			}
		}
	}

	public function uitloggen()
	{
		$this->session->ingelogd = FALSE;
		unset($_SESSION['gebruiker']);

		$data['naam'] = $this->session->gebruiker['nickname'];
		$data['ingelogd'] = $this->session->ingelogd;

		$this->load->view('templates/header', $data);
		$this->load->view('user/uitloggensucces');
		$this->load->view('templates/footer');
	}
}