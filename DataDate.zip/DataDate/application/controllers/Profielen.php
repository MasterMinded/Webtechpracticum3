<?php
class Profielen extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('profielen_model');
	}

	public function index()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');

		
		$data['profielen'] = $this->profielen_model->verkrijg_profielen($this->session->gebruiker);
		$data['merknamen'] = $this->profielen_model->verkrijg_merknamen();
		$data['title'] = "Profielen";
		$data['gebruiker'] = $this->session->gebruiker;
		$data['ingelogd'] = $this->session->ingelogd;

		$this->form_validation->set_rules('geslachtsvoorkeur', 'Geslachtsvoorkeur', 'required');
    	$this->form_validation->set_rules('minleeftijd', 'minimale leeftijd', 'required');
    	$this->form_validation->set_rules('maxleeftijd', 'maximale leeftijd', 'required');

		if($this->form_validation->run() === FALSE)
		{
			$this->load->view('templates/header', $data);
			$this->load->view('profielen/index', $data);
			$this->load->view('templates/footer');
		}
		else
		{
			$data['profielen'] = $this->profielen_model->zoek_profielen();

			$this->load->view('templates/header', $data);
			$this->load->view('profielen/zoeken', $data);
			$this->load->view('templates/footer');
		}
	}

	public function view($accountID = NULL)
	{
		$data['profiel'] = $this->profielen_model->verkrijg_profiel($accountID);
		$data['likes'] = $this->profielen_model->verkrijg_likes($accountID);
		$data['merknamen'] = $this->profielen_model->verkrijg_merknamen();
		$data['title'] = $data['profiel']['nickname'];
		$data['gebruiker'] = $this->session->gebruiker;
		$data['ingelogd'] = $this->session->ingelogd;

		if (empty($data['profiel']))
        {
                show_404();
        }

        $this->load->view('templates/header', $data);
        $this->load->view('profielen/view', $data);
        $this->load->view('templates/footer');
	}
}