<?php
class AJAX extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('ajax_model');
		$this->load->model('profielen_model');
	}

	public function like()
	{
		$this->ajax_model->like( $this->session->gebruiker);
	}

	public function meerProfielen()
	{
		$data['profielen'] = $this->ajax_model->verkrijg_meer_profielen($this->session->gebruiker);
		$data['merknamen'] = $this->profielen_model->verkrijg_merknamen();
		$data['gebruiker'] = $this->session->gebruiker;
		$data['ingelogd'] = $this->session->ingelogd;

		$this->load->view('ajax/meerProfielen', $data);
	}

	public function meerZoekProfielen()
	{
		
	}
}