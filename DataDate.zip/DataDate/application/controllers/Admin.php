<?php
class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
	}

	public function index()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->form_validation->set_rules('afstandsmaat', 'Afstandsmaat', 'required');
    	$this->form_validation->set_rules('x', 'X', 'required')
    	;$this->form_validation->set_rules('alfa', 'Alfa', 'required');

		$data['title'] = "Admin";
		$data['gebruiker'] = $this->session->gebruiker;
		$data['ingelogd'] = $this->session->ingelogd;
		$data['config'] = $this->admin_model->get_config();

		// Check of de gebruiker een admin is
		if($this->session->gebruiker['admin'] == 1)
		{
			if($this->form_validation->run() === FALSE)
			{
				$this->load->view('templates/header', $data);
				$this->load->view('admin/index', $data);
				$this->load->view('templates/footer');
			}
			else
			{
				// Verander de config waardes in de database
				$this->admin_model->update_config();
			}
		}
		else
		{
			$this->load->view('templates/header', $data);
			$this->load->view('admin/geentoegang', $data);
			$this->load->view('templates/footer');
		}
	}
}
