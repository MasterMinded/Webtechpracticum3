<?php 
	$this->load->helper('date'); 
	$this->load->helper('url');
?>

<?php 
	$i = 0;
	foreach ($profielen as $profiel):
		$i++; ?>
	
	<div class='profiel'>
		<a href="profielen/<?php echo $profiel['accountID'] ?>"><?php if ($profiel['geslacht'] == 'M')
			{	
				echo "<img class='fotothumbnail' src='" . base_url("images/silhouetM.png") . "'>";
			}
			else
			{
				echo "<img class='fotothumbnail' src='" . base_url("images/silhouetF.png") . "'>";
			}?></a>
		
		<h2><a href="profielen/<?php echo $profiel['accountID'] ?>"><?php echo $profiel['nickname'] ?></a>
			<?php if ($profiel['geslacht'] == 'M')
			{
				echo "<span class='blue'>&#9794</span>";
			}
			else
			{
				echo "<span class='pink'>&#9792</span>";
			}
		?></h2>

		<h3><?php 
		// Leeftijd rekenen

		$geboortedatum = $profiel['geboortedatum'];

		$geboortedatum = explode("-", $geboortedatum);

		if (date("md", date("U", mktime(0, 0, 0, $geboortedatum[1], $geboortedatum[2], $geboortedatum[0]) )) > date("md"))
		{
			$leeftijd = (date("Y") - $geboortedatum[0]) - 1;
		}
		else
		{
			$leeftijd = date("Y") - $geboortedatum[0];
		}
		   
		echo "Leeftijd: " . $leeftijd;

		?></h3>

		<p><?php
		// Neem alleen de eerste zin
		$beschrijving = explode(".", $profiel['beschrijving']);
		echo $beschrijving[0] . "."; 
		?></p>

		<p><?php
		// Toon persoonlijkheidstype
		if($profiel['E'] >= 50)
		{
			echo 'E(' . $profiel['E'] . '%) ';
		}
		else
		{
			echo 'I(' . (100 - $profiel['E']) . '%) ';
		}

		if($profiel['T'] >= 50)
		{
			echo 'T(' . $profiel['T'] . '%) ';
		}
		else
		{
			echo 'F(' . (100 - $profiel['T']) . '%) ';
		}

		if($profiel['S'] >= 50)
		{
			echo 'S(' . $profiel['S'] . '%) ';
		}
		else
		{
			echo 'N(' . (100 - $profiel['S']) . '%) ';
		}

		if($profiel['J'] >= 50)
		{
			echo 'J(' . $profiel['J'] . '%) ';
		}
		else
		{
			echo 'P(' . (100 - $profiel['J']) . '%) ';
		}

		?></p>

		<p><?php
		// Toon merkvoorkeuren
		$j = 0;
		foreach($merknamen as $merk)
		{
			if ($profiel[$merk['merkID']] == 1 && $j < 5)
			{
				$merkLijst[$j] = $merk['merkNaam'];
				$j++;
			}
		}

		$merkLijst = implode(", ", $merkLijst);
		if ($j >= 5)
		{
			$merkLijst .= "...";
		}
		echo $merkLijst;
		unset( $merkLijst );

		?></p>

	</div>
<?php endforeach ?>
<?php if ($i == 0)
	{
		echo "U heeft momenteel geen matches :(";
	}
?>