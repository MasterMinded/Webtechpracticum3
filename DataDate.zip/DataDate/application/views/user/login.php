<?php echo validation_errors(); ?>

<?php echo form_open('user/login'); ?>
	<table>
		<tr><td><label for="email">Email Adres: </label></td>
		<td><input type="text" name="email"></td></tr>
		
		<tr><td><label for="wachtwoord">Wachtwoord: </label></td>
		<td><input type="password" name="wachtwoord"></td></tr>
	</table>

	<input type="submit" name="submit" value="Inloggen">
</form>