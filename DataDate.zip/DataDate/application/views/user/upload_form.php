<?php echo form_open_multipart('upload/do_upload');?>
Upload een foto van jezelf (max 800x800px, 1MB): <br><br>
<input type="file" name="userfile" size="20" accept='image/*'><br><br>
<input type="submit" value="Upload">