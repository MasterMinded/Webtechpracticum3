<script>
$( document ).ready(function () {

	$("#verwijderen").click(function()
	{
		if (confirm("Weet U zeker dat u uw account wilt verwijderen? Deze actie kan niet ongedaan worden"))
		{
			alert("deleted!");
			window.location.replace("<?php echo site_url('user/verwijderen'); ?>");
		}
	});

});

</script>





<h2><?php echo $gebruiker['voornaam'] . " " . $gebruiker['achternaam'];?>
	<?php if ($gebruiker['geslacht'] == 'M')
			{
				echo "<span class='blue'>&#9794</span>";
			}
			else
			{
				echo "<span class='pink'>&#9792</span>";
			}?></h2>
<h3><?php echo $gebruiker['nickname'];?></h3>

<?php echo validation_errors(); ?>

<?php echo form_open('user/userpagina'); ?>
		<label for="beschrijving">Beschrijving: </label><br>
		<textarea name="beschrijving"><?php echo $gebruiker['beschrijving']; ?></textarea><br>

	<input type="submit" name="submit" value="Pas gegevens aan">
</form>

<button class="red" id="verwijderen">Verwijder account</button>