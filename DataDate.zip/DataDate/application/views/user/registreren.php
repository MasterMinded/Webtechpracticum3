Maak een nieuw account aan!<br><br>

<!--<head>
  <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
  
  <script>
  $(document).ready(function() {
    $("#datepicker").datepicker();
  });
  </script>
</head>-
<script>
function validateForm() {
	var user=mail=pass1=pass2=name=surname=dob=gender=genpref=agemin=agemax=foto=about=""
	user = document.forms["register"]["gebruikersnaam"].value;
	mail = document.forms["register"]["mail"].value;
	pass1 = document.forms["register"]["wachtwoord1"].value;
	pass2 = document.forms["register"]["wachtwoord2"].value;
	name = document.forms["register"]["voornaam"].value;
	surname = document.forms["register"]["achternaam"].value;
	dob = document.forms["register"]["dob"].value;
	gender = document.forms["register"]["geslacht"].value;
	genpref = document.forms["register"]["voorkeur"].value;
	agemin = document.forms["register"]["agemin"].value;
	agemax = document.forms["register"]["agemax"].value;
	foto = document.forms["register"]["foto"].value;
	about = document.forms["register"]["aboutyou"].value;
    if (user == "" || mail == "" || pass1 == "" || pass2 == "" || name == "" || surname == "" || dob == "" 
		|| gender == "" || genpref == ""|| agemin == "" || agemax == "" || foto == "" || about == "") {
        alert("Beantwoord alle vragen.");
        return false;
    }
}
</script>-->
<?php //echo validation_errors(); ?>
<?php echo form_open ('user/registreren'); ?>
	<table>
		<tr><td><label for="gebruikersnaam">Gebruikersnaam: </label></td>
		<td><input type="text" name="gebruikersnaam"></td></tr>
		
		<tr><td><label for="mail">Emailadres: </label></td>
		<td><input type="email" name="mail"></td></tr>
		
		<tr><td><label for="wachtwoord1">Wachtwoord: </label></td>
		<td><input type="password" name="wachtwoord1"></td></tr>
		
		<tr><td><label for="wachtwoord2">Herhaal wachtwoord: </label></td>
		<td><input type="password" name="wachtwoord2"></td></tr>
		
		<tr><td><label for="voornaam">Voornaam: </label></td>
		<td><input type="text" name="voornaam"></td></tr>
		
		<tr><td><label for="achternaam">Achternaam: </label></td>
		<td><input type="text" name="achternaam"></td></tr>
		
		<tr><td><label for="dob">Geboortedatum: </label></td>
		<td><!--<input id="datepicker">--><input type="date" name="dob"></td></tr>
		
		<tr><td><label for="geslacht">Geslacht: </label></td></tr>
		<tr><td><input type="radio" name="geslacht" value="M">Man</td></tr>
		<tr><td><input type="radio" name="geslacht" value="V">Vrouw</td></tr>
		
		<tr><td><label for="voorkeur">Geslachtsvoorkeur: </label></td></tr>
		<tr><td><input type="radio" name="voorkeur" value="M">Man</td></tr>
		<tr><td><input type="radio" name="voorkeur" value="V">Vrouw</td></tr>
		<tr><td><input type="radio" name="voorkeur" value="B">Beide</td></tr>
		
		<tr><td><label for="agemin">Leeftijdsvoorkeur van (min. 18): </label></td>
		<td><input type="number" name="agemin" min="18" max="999" size=1> 
		
		<label for="agemax">tot: </label> 
		<input type="number" name="agemax" min="18" max="999" size=1></td></tr>
		
		<!--<tr><td><label for="foto">Upload een foto van jezelf<br>(max 800x800px, 1MB): </label></td>
		<td><input type='file' name='foto' accept='image/*'></td></tr>-->
	</table>
		<p><label for="aboutyou">Iets over jezelf: <br></label>
		<textarea name='aboutyou' id='aboutyou' rows='5'></textarea></p>
	
	<p><input type="submit" name="submit" value="Registreren"></p>
</form>