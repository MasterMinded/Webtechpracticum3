<script>
	$(function() 
	{
		// Initiele waardes
		$("#xwaarde").html("X: " + $("#xslider").val() / 100);
		$("#alfawaarde").html("alfa: " + $("#alfaslider").val() / 100);
		$("#betawaarde").html("beta: " + ((100 - $("#alfaslider").val()) / 100));

		// Als de waardes van de sliders veranderen verandert ook de bijbehorende waarde in de tekst
		$("#xslider").on("change mousemove", function()
		{
			$("#xwaarde").html("X: " + $(this).val() / 100);
		});

		$("#alfaslider").on("change mousemove", function()
		{
			$("#alfawaarde").html("alfa: " + $(this).val() / 100);
			$("#betawaarde").html("beta: " + ((100 - $(this).val()) / 100));
		});
	});
</script>

<?php echo validation_errors(); ?>

<?php echo form_open('admin/index'); ?>
	<table>
		
		<tr><td><label for="afstandsmaat">Afstandsmaat voor lifestyle matching </label></td>
		<tr><td><input type="radio" name="afstandsmaat" value="1" <?php if ($config['afstandsmaat'] == 1) echo "checked"; ?>>1</td></tr>
		<tr><td><input type="radio" name="afstandsmaat" value="2" <?php if ($config['afstandsmaat'] == 2) echo "checked"; ?>>2</td></tr>
		<tr><td><input type="radio" name="afstandsmaat" value="3" <?php if ($config['afstandsmaat'] == 3) echo "checked"; ?>>3</td></tr>
		<tr><td><input type="radio" name="afstandsmaat" value="4" <?php if ($config['afstandsmaat'] == 4) echo "checked"; ?>>4</td></tr>
		<tr><td>------------------------------</td></tr>
		
		
		<tr><td><label for="x">X waarde: </label></td></tr>
		<tr><td><input type="range" name="x" id="xslider" min="0" max="100" value="<?php echo $config['x']; ?>"></td></tr>
		<tr><td><span id="xwaarde"></span></td></tr>
		<tr><td>------------------------------</td></tr>
		

		<tr><td><label for="alfa">Alfa en Beta waardes: </label></td></tr>
		<tr><td><input type="range" name="alfa" id="alfaslider" min="0" max="100" value="<?php echo $config['alfa']; ?>"></td></tr>
		<tr><td><span id="alfawaarde"></span> <span id="betawaarde"></span></td></tr>
	</table>

	<input type="submit" name="submit" value="Opslaan">
</form>