<html>
<head>
    <meta charset="UTF-8">
	<title>DataDate - <?php echo $title; ?></title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<?php $this->load->helper('url'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("stylesheets/style.css") ?>">
</head>
<body>
	<div id='topBar'>
		<ul>
    		<li><a href="<?php echo site_url('home')?>" id="index">				Home		</a></li>
    		<li><a href="<?php echo site_url('profielen')?>" id="info">			Profielen	</a></li> 
    		<div id='topBar_right'>
    			<?php if($this->session->ingelogd === TRUE): ?>
    				<li><a href="<?php echo site_url('user/userpagina')?>" id="userpagina"><?php echo $gebruiker['nickname'];?></a></li> |
    				<li><a href="<?php echo site_url('user/uitloggen')?>" id="uitloggen">	uitloggen </a></li>
                    <?php if($gebruiker['admin'] == 1): ?>
                         | <li><a href="<?php echo site_url('admin')?>" id="admin">Admin</a></li>
                    <?php endif ?>
    			<?php else: ?>
    				<li><a href="<?php echo site_url('user/login')?>" id="login">		login		</a></li>|
    				<li><a href="<?php echo site_url('user/registreren')?>" id="registreren">	registreren	</a></li>
    			<?php endif ?>
    		</div>
		</ul>
	</div>
	<div id='content'>