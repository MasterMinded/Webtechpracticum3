<script>
$( document ).ready(function () {
	var aantalPulls = 1;

	$("#bekijkMeer").click(function()
	{
		

		$.ajax({
			url: <?php echo "'" . site_url('ajax/meerZoekProfielen') . "'"?>,
			data: "pagina=" + aantalPulls,
			type: "post",
			success: function(response)
				{
					$(response).insertAfter(".profiel:last");
				}
		});

		aantalPulls++;
	});

});

</script>









<h1>Zoekresultaten</h1>

<?php $this->load->helper('date'); ?>

<?php 
	$i = 0;
	foreach ($profielen as $profiel):
		$i++; ?>
	
	<div class='profiel'>
		<a href="profielen/<?php echo $profiel['accountID'] ?>"><?php if ($profiel['geslacht'] == 'M')
			{	
				echo "<img class='fotothumbnail' src='" . base_url("images/silhouetM.png") . "'>";
			}
			else
			{
				echo "<img class='fotothumbnail' src='" . base_url("images/silhouetF.png") . "'>";
			}?></a>
		
		<h2><a href="profielen/<?php echo $profiel['accountID'] ?>"><?php echo $profiel['nickname'] ?></a>
			<?php if ($profiel['geslacht'] == 'M')
			{
				echo "<span class='blue'>&#9794</span>";
			}
			else
			{
				echo "<span class='pink'>&#9792</span>";
			}
		?>
		<?php
			if($ingelogd === TRUE)
			{
				if ($profiel['like'] == 1)
				{
					echo '<span class="red">&hearts; you like '. $profiel['nickname'] . "!</span>";
				}
				elseif ($profiel['like'] == 2)
				{
					echo '<span class="red">&hearts; ' . $profiel['nickname'] . ' likes you!</span>';
				}
				elseif ($profiel['like'] == 3)
				{
					echo '<span class="red">&hearts; &hearts; jullie liken elkaar!</span>';
				}
			}
		?></h2>

		<h3><?php 
		// Leeftijd rekenen

		$geboortedatum = $profiel['geboortedatum'];

		$geboortedatum = explode("-", $geboortedatum);

		if (date("md", date("U", mktime(0, 0, 0, $geboortedatum[1], $geboortedatum[2], $geboortedatum[0]) )) > date("md"))
		{
			$leeftijd = (date("Y") - $geboortedatum[0]) - 1;
		}
		else
		{
			$leeftijd = date("Y") - $geboortedatum[0];
		}
		   
		echo "Leeftijd: " . $leeftijd;

		?></h3>

		<p><?php
		// Neem alleen de eerste zin
		$beschrijving = explode(".", $profiel['beschrijving']);
		echo $beschrijving[0] . "."; 
		?></p>

		<p><?php
		// Toon persoonlijkheidstype
		if($profiel['E'] >= 50)
		{
			echo 'E(' . $profiel['E'] . '%) ';
		}
		else
		{
			echo 'I(' . (100 - $profiel['E']) . '%) ';
		}

		if($profiel['T'] >= 50)
		{
			echo 'T(' . $profiel['T'] . '%) ';
		}
		else
		{
			echo 'F(' . (100 - $profiel['T']) . '%) ';
		}

		if($profiel['S'] >= 50)
		{
			echo 'S(' . $profiel['S'] . '%) ';
		}
		else
		{
			echo 'N(' . (100 - $profiel['S']) . '%) ';
		}

		if($profiel['J'] >= 50)
		{
			echo 'J(' . $profiel['J'] . '%) ';
		}
		else
		{
			echo 'P(' . (100 - $profiel['J']) . '%) ';
		}

		?></p>

		<p><?php
		// Toon merkvoorkeuren
		$j = 0;
		foreach($merknamen as $merk)
		{
			if ($profiel[$merk['merkID']] == 1 && $j < 5)
			{
				$merkLijst[$j] = $merk['merkNaam'];
				$j++;
			}
		}

		$merkLijst = implode(", ", $merkLijst);
		if ($j >= 5)
		{
			$merkLijst .= "...";
		}
		echo $merkLijst;
		unset( $merkLijst );

		?></p>

	</div>
<?php endforeach ?>
<?php if ($i == 0)
	{
		echo "Uw zoekparameters matchen geen profielen";
	}
?>

<button id="bekijkMeer">Bekijk Meer</button>