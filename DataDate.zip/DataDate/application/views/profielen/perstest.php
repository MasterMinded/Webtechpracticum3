<?php

/*function strip($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = strip_tags($tekst);
   $data = htmlspecialchars($data);
   return $data;
}*/

$E=$I=$N=$S=$T=$F=$J=$P=50;

$q1=$_POST["q1"];
$q2=$_POST["q2"];
$q3=$_POST["q3"];
$q4=$_POST["q4"];
$q5=$_POST["q5"];
$q6=$_POST["q6"];
$q7=$_POST["q7"];
$q8=$_POST["q8"];
$q9=$_POST["q9"];
$q10=$_POST["q10"];
$q11=$_POST["q11"];
$q12=$_POST["q12"];
$q13=$_POST["q13"];
$q14=$_POST["q14"];
$q15=$_POST["q15"];
$q16=$_POST["q16"];
$q17=$_POST["q17"];
$q18=$_POST["q18"];
$q19=$_POST["q19"];

$EI=array($q1, $q2, $q3, $q4, $q5);
$NS=array($q6, $q7, $q8, $q9);
$TF=array($q10, $q11, $q12, $q13);
$JP=array($q14, $q15, $q16, $q17, $q18, $q19);

IF ($q1!="" && $q2!="" && $q3!="" && $q4!="" && $q5!="" && $q6!="" && $q7!="" && $q8!="" && $q9!="" && $q10!="" &&
	$q11!="" && $q12!="" && $q13!="" && $q14!="" && $q15!="" && $q16!="" && $q17!="" && $q18!="" && $q19!="")
{
$countEI=array_count_values($EI);
$E=$E+($countEI['a']*10);
$I=$I-($countEI['a']*10);
$E=$E-($countEI['b']*10);
$I=$I+($countEI['b']*10);

$countNS=array_count_values($NS);
$N=$N+($countNS['a']*12.5);
$S=$S-($countNS['a']*12.5);
$N=$N-($countNS['b']*12.5);
$S=$S+($countNS['b']*12.5);

$countTF=array_count_values($TF);
$T=$T+($countTF['a']*12.5);
$F=$F-($countTF['a']*12.5);
$T=$T-($countTF['b']*12.5);
$F=$F+($countTF['b']*12.5);

$countJP=array_count_values($JP);
$J=$J+($countJP['a']*(8+(1/3)));
$P=$P-($countJP['a']*(8+(1/3)));
$J=$J-($countJP['b']*(8+(1/3)));
$P=$P+($countJP['b']*(8+(1/3)));

$score=array("E"=>$E, "I"=>$I, "N"=>$N, "S"=>$S, "T"=>$T, "F"=>$F, "J"=>$J, "P"=>$P);
arsort($score);
}

foreach($score as $t=>$t_value) {
     echo $t.": ".round($t_value)."%<br>";
	}
?>