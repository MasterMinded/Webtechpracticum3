<script>
$( document ).ready(function () {
	$("#like").click(function()
	{
		var postAccountID = <?php echo $profiel['accountID']; ?>;
		var likeStatus = <?php echo $likes['like']; ?>;

		$.ajax({
			url: <?php echo "'" . site_url('ajax/like') . "'"?>,
			data: "accountID=" + postAccountID,
			type: "post",
			success: function(response)
				{
					$("#like").html("Liked");
					$("#like").attr("disabled", true);

					if( likeStatus == 2)
					{
						$("#likestatus").text("\u2665 \u2665 jullie liken elkaar!");
					}
				}
		});
	});
});

</script>





<?php 
	if ($ingelogd === TRUE && $profiel['foto'] !== NULL)
	{
		echo "<img src='" . base_url("images/profiel/" . $profiel['foto']) . "'>";
	}
	else
	{
		if ($profiel['geslacht'] == 'M')
		{	
			echo "<img src='" . base_url("images/defaults/silhouetMthumbnail.png") . "'>";
		}
		else
		{
			echo "<img src='" . base_url("images/defaults/silhouetFthumbnail.png") . "'>";
		}
	}
?>

<h2>
<?php 
	if ($likes['like'] == 3)
	{
		echo $profiel['voornaam'] . " " . $profiel['achternaam'] . " <i>'" . $profiel['nickname'] . "'</i>";
	}
	else
	{
		echo $profiel['nickname'];
	}

?>
<?php 
	if ($profiel['geslacht'] == 'M')
	{
		echo "<span class='blue'>&#9794</span>";
	}
	else
	{
		echo "<span class='pink'>&#9792</span>";
	}
?>
<?php 
	if ($ingelogd === TRUE)
	{
		if ($likes['like'] == 0)
		{
			echo '<button id="like">Like</button>';
		}
		elseif ($likes['like'] == 1)
		{
			echo '<button id="like" disabled>Liked</button>';
		}
		elseif ($likes['like'] == 2)
		{
			echo '<button id="like">Like</button><span id="likestatus" class="red">&hearts; ' . $profiel['nickname'] . ' likes you!</span>';
		}
		elseif ($likes['like'] == 3)
		{
			echo '<button id="like" disabled>Liked</button><span id="likestatus" class="red">&hearts; &hearts; jullie liken elkaar!</span>';
		}
	}
		
?>

</h2>

Zoekt een <?php 
	if($profiel['geslachtsvoorkeur'] == "M")
	{
		echo "Man";
	}
	elseif($profiel['geslachtsvoorkeur'] == "F")
	{
		echo "Vrouw";
	}
	elseif($profiel['geslachtsvoorkeur'] == "B")
	{
		echo "Man of vrouw";
	}?> tussen de
	<?php
		echo $profiel['leeftijdsvoorkeurmin'];
	?> en 
	<?php 
		echo $profiel['leeftijdsvoorkeurmax'];
	?>

<h4>Beschrijving</h4>
<p><?php echo $profiel['beschrijving']; ?></p>

<h3>Persoonlijkheid</h3>
<?php
	// Toon persoonlijkheidstype
	if($profiel['E'] >= 50)
	{
		echo 'E(' . $profiel['E'] . '%) ';
	}
	else
	{
		echo 'I(' . (100 - $profiel['E']) . '%) ';
	}

	if($profiel['T'] >= 50)
	{
		echo 'T(' . $profiel['T'] . '%) ';
	}
	else
	{
		echo 'F(' . (100 - $profiel['T']) . '%) ';
	}

	if($profiel['S'] >= 50)
	{
		echo 'S(' . $profiel['S'] . '%) ';
	}
	else
	{
		echo 'N(' . (100 - $profiel['S']) . '%) ';
	}

	if($profiel['J'] >= 50)
	{
		echo 'J(' . $profiel['J'] . '%) ';
	}
	else
	{
		echo 'P(' . (100 - $profiel['J']) . '%) ';
	}
?>

<h3>Persoonlijkheidsvoorkeur</h3>
<?php
	// Toon persoonlijkheidstype
	if($profiel['Evoorkeur'] >= 50)
	{
		echo 'E(' . $profiel['Evoorkeur'] . '%) ';
	}
	else
	{
		echo 'I(' . (100 - $profiel['Evoorkeur']) . '%) ';
	}

	if($profiel['Tvoorkeur'] >= 50)
	{
		echo 'T(' . $profiel['Tvoorkeur'] . '%) ';
	}
	else
	{
		echo 'F(' . (100 - $profiel['Tvoorkeur']) . '%) ';
	}

	if($profiel['Svoorkeur'] >= 50)
	{
		echo 'S(' . $profiel['Svoorkeur'] . '%) ';
	}
	else
	{
		echo 'N(' . (100 - $profiel['Svoorkeur']) . '%) ';
	}

	if($profiel['Jvoorkeur'] >= 50)
	{
		echo 'J(' . $profiel['Jvoorkeur'] . '%) ';
	}
	else
	{
		echo 'P(' . (100 - $profiel['Jvoorkeur']) . '%) ';
	}
?>


<h3>Merkvoorkeuren</h3>
<?php foreach($merknamen as $merk)
	{
		if ($profiel[$merk['merkID']] == 1)
		echo $merk['merkNaam'] . "<br>";
	}
?>

<br><br>
<?php if($ingelogd === TRUE): ?>
	<?php
	if ($likes['like'] == 3)
	{
		echo "<h3>Contact Gegevens</h3>Email: " . $profiel['emailadres'];
	}
	?>
<?php else: ?>
	<a href="<?php echo site_url('user/login')?>">Contact</a>
<?php endif ?>









