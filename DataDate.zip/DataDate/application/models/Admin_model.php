<?php
class Admin_model extends CI_MODEL
{
	public function __construct()
	{
		$this->load->database();
	}

	public function get_config()
	{
		$query = $this->db->get('Config');
    	return $query->row_array();
	}

	public function update_config()
	{
		// Pas de config waardes in de database aan
		$afstandsmaat = $this->input->post('afstandsmaat');
		$x = $this->input->post('x');
		$alfa = $this->input->post('alfa');
		$beta = 100 - $alfa;

		$data = array(
			'afstandsmaat' => $afstandsmaat,
			'x' => $x,
			'alfa' => $alfa,
			'beta' => $beta
		);

		$this->db->update('Config', $data);
	}
}