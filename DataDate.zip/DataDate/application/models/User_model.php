<?php
class User_model extends CI_MODEL
{
	public function __construct()
	{
		$this->load->database();
	}

	public function login()
	{
		$gebruikersnaam = $this->input->post('gebruikersnaam');
		$password = $this->input->post('wachtwoord');

		$query = $this->db->get_where('Accounts', array('nickname' => $gebruikersnaam));
		$result = $query->row_array();
		$hash = $result["wachtwoordhash"];


		if (password_verify($password, $hash))
		{
			//inloggen
			return $result;
		}
		else
		{
			//onjuist wachtwoord
			return FALSE;
		}
		
	}
	
	public function checkifnew()
	{
		$user = $this->input->post('gebruikersnaam');
		$email = $this->input->post('mail');

		$this->db->where('nickname', $user);
		$this->db->or_where('emailadres', $email);
		$this->db->from('Accounts');
		$count = $this->db->count_all_results();

		if($count>0)
			return FALSE;
		else
			return TRUE;
	}
}