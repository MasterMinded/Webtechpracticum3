<?php
class Ajax_model extends CI_MODEL
{
	public function __construct()
	{
		$this->load->database();
	}

	public function like($gebruiker = NULL)
	{
		if($gebruiker == NULL)
		{
			return;
		}
		// IDs van POST zijn anders dan de IDs in de database
		// 1 is liker
		// 2 is likee
		// In de database
		// 0 betekent geen likes
		// 1 betekent 1 liket 2
		// 2 betekent 2 liket 1
		// 3 betekent een wederzijds liking
		$accountID1 = $gebruiker["accountID"];
		$accountID2 = $this->input->post('accountID');

		$this->db->where( array(
			'accountID1' => $accountID1,
			'accountID2' => $accountID2,
			'like' => '0'
		) );
		$this->db->update('Likes', array(
			'like' => 1
		));

		$this->db->where( array(
			'accountID1' => $accountID1,
			'accountID2' => $accountID2,
			'like' => '2'
		) );
		$this->db->update('Likes', array(
			'like' => 3
		));

		$this->db->where( array(
			'accountID2' => $accountID1,
			'accountID1' => $accountID2,
			'like' => '0'
		) );
		$this->db->update('Likes', array(
			'like' => 2
		));

		$this->db->where( array(
			'accountID2' => $accountID1,
			'accountID1' => $accountID2,
			'like' => '1'
		) );
		$this->db->update('Likes', array(
			'like' => 3
		));


	}

	public function verkrijg_meer_profielen($gebruiker = NULL)
	{
		if ($gebruiker === NULL)
		{
			$this->db->select('*');
			$this->db->from('Accounts');
			$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID', "left");
			$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
			$this->db->limit(2,$this->input->post('pagina') * 2);
			$query = $this->db->get();
        	return $query->result_array();
		}

		// Bereken de data van de jongste en oudste mogelijke profiel
		$leeftijdmin = array( date('Y') - $gebruiker['leeftijdsvoorkeurmin'], date('m'), date('d') );
		$leeftijdmax = array( date('Y') - $gebruiker['leeftijdsvoorkeurmax'], date('m'), date('d') );

		$leeftijdmin = implode("-", $leeftijdmin);
		$leeftijdmax = implode("-", $leeftijdmax);

		// Bereken de leeftijd van de gebruiker
		$geboortedatum = $gebruiker['geboortedatum'];

		$geboortedatum = explode("-", $geboortedatum);

		if (date("md", date("U", mktime(0, 0, 0, $geboortedatum[1], $geboortedatum[2], $geboortedatum[0]) )) > date("md"))
		{
			$leeftijd = (date("Y") - $geboortedatum[0]) - 1;
		}
		else
		{
			$leeftijd = date("Y") - $geboortedatum[0];
		}

		$data = array(
			/*'geslacht' => $gebruiker['geslachtsvoorkeur'],
			'geslachtsvoorkeur' => $gebruiker['geslacht'],*/
			'Accounts.accountID !=' => $gebruiker['accountID'],
			'geboortedatum <=' => $leeftijdmin,
			'geboortedatum >=' => $leeftijdmax,
			'leeftijdsvoorkeurmin <=' => $leeftijd,
			'leeftijdsvoorkeurmax >=' => $leeftijd
		);

        $this->db->select('*');
		$this->db->from('Accounts');
		$this->db->where($data);
		if ($gebruiker['geslachtsvoorkeur'] != "B")
		{
			$this->db->where('geslacht', $gebruiker['geslachtsvoorkeur']);
		}
		$this->db->where("(geslachtsvoorkeur='" . $gebruiker['geslacht'] . "' OR geslachtsvoorkeur='B')");
		//$this->db->or_where('geslachtsvoorkeur', "B");
		$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID');
		$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
		$this->db->limit(2,$this->input->post('pagina') * 2);
		$query = $this->db->get();
        return $query->result_array();

	}

}