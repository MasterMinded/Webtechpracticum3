<?php
class Profielen_model extends CI_MODEL
{
	public function __construct()
	{
		$this->load->database();
	}

	public function verkrijg_profielen($gebruiker = NULL)
	{
		if ($gebruiker === NULL)
		{
			$this->db->select('*');
			$this->db->from('Accounts');
			$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID', "left");
			$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
			$this->db->limit(2,0);
			$query = $this->db->get();
        	return $query->result_array();
		}

		// Bereken de data van de jongste en oudste mogelijke profiel
		$leeftijdmin = array( date('Y') - $gebruiker['leeftijdsvoorkeurmin'], date('m'), date('d') );
		$leeftijdmax = array( date('Y') - $gebruiker['leeftijdsvoorkeurmax'], date('m'), date('d') );

		$leeftijdmin = implode("-", $leeftijdmin);
		$leeftijdmax = implode("-", $leeftijdmax);

		// Bereken de leeftijd van de gebruiker
		$geboortedatum = $gebruiker['geboortedatum'];

		$geboortedatum = explode("-", $geboortedatum);

		if (date("md", date("U", mktime(0, 0, 0, $geboortedatum[1], $geboortedatum[2], $geboortedatum[0]) )) > date("md"))
		{
			$leeftijd = (date("Y") - $geboortedatum[0]) - 1;
		}
		else
		{
			$leeftijd = date("Y") - $geboortedatum[0];
		}

		$data = array(
			/*'geslacht' => $gebruiker['geslachtsvoorkeur'],
			'geslachtsvoorkeur' => $gebruiker['geslacht'],*/
			'Accounts.accountID !=' => $gebruiker['accountID'],
			'geboortedatum <=' => $leeftijdmin,
			'geboortedatum >=' => $leeftijdmax,
			'leeftijdsvoorkeurmin <=' => $leeftijd,
			'leeftijdsvoorkeurmax >=' => $leeftijd
		);

        $this->db->select('*');
		$this->db->from('Accounts');
		$this->db->where($data);
		if ($gebruiker['geslachtsvoorkeur'] != "B")
		{
			$this->db->where('geslacht', $gebruiker['geslachtsvoorkeur']);
		}
		$this->db->where("(geslachtsvoorkeur='" . $gebruiker['geslacht'] . "' OR geslachtsvoorkeur='B')");
		//$this->db->or_where('geslachtsvoorkeur', "B");
		$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID');
		$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
		$this->db->limit(2,0);
		$query = $this->db->get();
		$results = $query->result_array();

		foreach($results as $key => $result)
		{
			$results[$key]['like'] = $this->verkrijg_likes($result['accountID'])['like'];
			
		}

        return $results;

	}

	public function zoek_profielen()
	{
		// Bereken de data van de jongste en oudste mogelijke profiel
		$leeftijdmin = array( date('Y') - $this->input->post('minleeftijd'), date('m'), date('d') );
		$leeftijdmax = array( date('Y') - $this->input->post('maxleeftijd'), date('m'), date('d') );

		$leeftijdmin = implode("-", $leeftijdmin);
		$leeftijdmax = implode("-", $leeftijdmax);

		$data = array(
			/*'geslacht' => $gebruiker['geslachtsvoorkeur'],
			'geslachtsvoorkeur' => $gebruiker['geslacht'],*/
			'geboortedatum <=' => $leeftijdmin,
			'geboortedatum >=' => $leeftijdmax,
		);

        $this->db->select('*');
		$this->db->from('Accounts');
		$this->db->where($data);
		if ($this->input->post('geslachtsvoorkeur') != "B")
		{
			$this->db->where('geslacht', $this->input->post('geslachtsvoorkeur'));
		}
		$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID');
		$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
		$this->db->limit(6,0);
		$query = $this->db->get();

		$results = $query->result_array();

		if($this->session->ingelogd === TRUE)
		{
			foreach($results as $key => $result)
			{
				$results[$key]['like'] = $this->verkrijg_likes($result['accountID'])['like'];	
			}
		}

        return $results;

	}	

	public function verkrijg_profiel($accountID = NULL)
	{
		$this->db->select('*');
		$this->db->from('Accounts');
		$this->db->where('Accounts.accountID', $accountID);
		$this->db->join('Merkvoorkeuren', 'Merkvoorkeuren.accountID = Accounts.accountID', "left");
		$this->db->join('Persoonlijkheid', 'Persoonlijkheid.accountID = Accounts.accountID', "left");
		$query = $this->db->get();
        return $query->row_array();
	}

	public function verkrijg_likes($accountID = NULL)
	{
		$query = $this->db->get_where('Likes', array('accountID1' => $accountID, 'accountID2' => $this->session->gebruiker['accountID']));
		$results = $query->row_array();
		if($results !== NULL)
		{
			if ($results['like'] == 2)
			{
				$results['like'] = 1;
			}
			elseif ($results['like'] == 1)
			{
				$results['like'] = 2;
			}
			return $results;
		}
		else
		{
			$query = $this->db->get_where('Likes', array('accountID2' => $accountID, 'accountID1' => $this->session->gebruiker['accountID']));
			return $query->row_array();
		}

	}

	public function verkrijg_merknamen()
	{
		$query = $this->db->get('Merken');
        return $query->result_array();
	}
}